<?php
session_start();
include "../config.php";
include '../date.php';


 $ide = $_POST["ide"];

 echo $ide;



// $sql = mysqli_query($link,"SELECT * FROM objects WHERE obj_name = '$ide' GROUP BY section_flat HAVING COUNT(section_flat) > 0");
// $row = mysqli_fetch_assoc($sql);
//  $extr = array();
//  array_push($extr, $row['id']);
//     $section = explode(",", $row['section_flat']);
//     array_pop($section);
 /*
 while ($row = mysqli_fetch_assoc($sql)) {
    array_push($extr, $row['id']);
    $section = explode(",", $row['section_flat']);
    array_pop($section);
 }
*/


?>
<thead>
  <tr>
  <?php  
    $sql2 = mysqli_query($link,"SELECT * FROM sections WHERE parent = 'flat'");

    $temp_arr = [];

    while ($row = mysqli_fetch_assoc($sql2)) {
       array_push($temp_arr,$row['id']);
        ?>
          <th><?=$row['section_name']?></th>
        <?
    }
    $temp_arr2 = [];

    $sql3 = mysqli_query($link,"SELECT * FROM extra_object WHERE object_name = '$ide'");

    while ($row3 = mysqli_fetch_assoc($sql3)) {
       array_push($temp_arr2,$row3);
    }

     
  ?>                                    
     <th>Flat</th>
     <th>Edit</th>
     <th>Delete</th>
     <th>Created date</th>
     <th>Updated date</th>

  </tr>
  </thead>
<tbody>
  <tr>
      <?php
        
         foreach ($temp_arr2 as $key => $value) {
          echo $value
          foreach ($temp_arr as $key2 => $value2) {
             if($value['surface'] == $value2){
                ?>
                  <td><?=$value['surface']?></td>

                <?
             }
             else {
                ?>
                  <td>0</td>
                <?
             }
          }

      ?>
         <td><?=$value['flat']?></td>
         <td><a class="btn btn-success" href="edit.php?id=<?=$value['id']?>"><i class="fa fa-pencil"></i></a></td>
         <td>
            <form id="delete" class="">
            <button type="button" class="btn btn-danger uchir" salom="<?=$row['id']?>"><i class="fa fa-trash"></i></button>
            </form>
        </td>
         <td><?=date("Y-m-d",$value['flat']);?></td>
         <td>
          <?php
           if($value['updated_date']) echo $value['update'];
           else echo 0;
            ?>
          </td>
    </tr>
</tbody>
<?
       }
?>
   



 <div class="row mb-3" >
                                 
                                    <div class="col-lg-4" id="test">
                                       <i class=" fas fa-hospital "></i>
                                       <label> Objects</label>
                                       <select  name="object_name" class="form-control object" placeholder="Address" required 
                                          style="background-color: #F8F8F8 !important;" id="object" onchange="b()">
                                          <option>Choose object</option>
                                          <?php 
                                             while ($rows = mysqli_fetch_assoc($sql)) {
                                                ?>
                                                   <option value="<?=$rows['obj_name']?>">
                                                   <?php echo $rows['obj_name'];?>
                                                   </option>
                                                <?
                                             }
                                          ?>

                                       </select>
                                    </div>

                                    <div class="col-lg-4" id="selroom">
                                       <i class="fa fa-house"></i>
                                       <label> Flat</label> 
                                        <select name="room" class="js-example-basic-single bg-light form-control" 
                                        style="background-color: #F8F8F8 !important;">
                                        <option>Choose flat</option>
                                         
                                      </select>
                                    </div>

                                    <div class="col-lg-4" id="selroom">
                                       <i class="fa fa-calendar"></i>
                                       <label> Date</label> 
                                        <input type="date" name="date" class="form-control">
                                    </div>

                                 </div>

                                 <diw class="row mb-3"></diw>
                                    
                                     <div class="row" id="test">
                                       <div class="col-lg-4">
                                          <?php 
                                             $sql2 = mysqli_query($link,"SELECT * FROM sections WHERE parent='flat'");

                                             while ($row2 = mysqli_fetch_assoc($sql2)) {
                                                 $count = count($row2);

                                                 ?>
                                                    <br />
                                                    <i class=" fas fa-calculator "></i>
                                                    <label><?=$row2['section_name']?></label>
                                                    <input type="text" name="<?=$row2['section_name']?>" class="form-control object" placeholder="<?=$row2['section_name']?> surface" required style="background-color: #F8F8F8 !important;" id="surface">

                                                    <i class="mdi mdi-worker"></i>
                                                   <label>Workers</label><br>
                                                   <select name="worker[]" class="js-example-basic-multiple form-control" multiple="multiple" style="background-color: #F8F8F8 !important;width: 380px !important; " required>
                                                    <?php 
                                                      $sql3 = mysqli_query($link,"SELECT * FROM workers");
                                                      while($rows = mysqli_fetch_assoc($sql3)){
                                                         ?>
                                                            <option class="form-control" value="<?=$rows['id']?>"><?=$rows['name']?></option>
                                                         <?
                                                      }
                                                    ?>
                                                   </select>
                                                 <?

                                             }
                                        ?>
                                       </div>  
                                    </div>
                                  
                                 
                                 </div>

                                     

                                    <div class="col-lg-4">
                                       <i class="mdi mdi-worker"></i>
                                       <label>Workers</label><br>
                                       <select name="worker[]" class="js-example-basic-multiple form-control" multiple="multiple" style="background-color: #F8F8F8 !important;width: 380px !important; " required>
                                        <?php 
                                          $sql3 = mysqli_query($link,"SELECT * FROM workers");
                                          while($rows = mysqli_fetch_assoc($sql3)){
                                             ?>
                                                <option class="form-control" value="<?=$rows['id']?>"><?=$rows['name']?></option>
                                             <?
                                          }
                                        ?>
                                       </select>
                                    </div>

                                    <div class="col-lg-3">
                                       <label>Comment</label><br>
                                        <div class="row">
                                            <div class="col-md-2">
                                                <input name="check" class=" form-control flexCheckDefault " type="checkbox" value="true" id="flexCheckDefault" style="width:50px !important;height: 35px;background-color:red !important;" onchange="com()" id="">
                                            </div>
                                            <div class="col-md-10 comment" id="com">
                                                <input type="text" name="comment" class="form-control "
                                                style="background-color: #F8F8F8 !important;">
                                            </div>
                                        </div>
                                    </div>

                                    
                                 </div>



$row2 = mysqli_fetch_assoc($sql2);
                                             $count = count($row2);
                                             for($i = 0; $i <= $count; $i++){
                                                ?>
                                                   <i class=" fas fa-calculator "></i>
                                                   <label> Surface 2^m</label>
                                                   <input type="text" name="surface" class="form-control object" placeholder="surface" required style="background-color: #F8F8F8 !important;" id="surface">
                                                <?
                                             }



$sql = mysqli_query($link,"SELECT extra_object.object_name,objects.obj_name, extra_object.section, SUM(extra_object.surface),extra_object.created_date,extra_object.updated_date
      FROM objects INNER JOIN extra_object  ON objects.obj_name=extra_object.object_name GROUP BY section HAVING COUNT(extra_object.section) > 0");
<?php 
session_start();
include '../config.php';
include '../date.php';

$sql_project = mysqli_query($link,"SELECT * FROM projects");

$title = "OBJECTS - ROBO";

 if($_SESSION['user']){
 
 require "$_SERVER[DOCUMENT_ROOT]/header.php";   

?>

        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">
                             <button onclick="myFunction()" class="font-light text-white m-b-20 btn btn-primary" >
                                    <span style="font-size:14px !important;">Add <i class="fa fa-plus"></i></span>
                                   </button  name="add"><br>
                        </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">

             <div id="" >
                  <div class="row" >
                      <div class="col-lg-12">
                         <div class="card" >
                            <div class="card-body" >
                             <form method="POST" id="object" >
                               <div class="row mb-3" >
                                   <div class="col-lg-4">
                                    <i class=" fas fa-hospital-alt "></i>
                                     <label> Project id</label> 
                                     <select name="project_id" class="form-control" placeholder="Address" required 
                                      style="background-color: #F8F8F8 !important;">
                                     <?php 
                                        foreach($sql_project as $opt){
                                     ?>
                                        <option value="<?=$opt['id'];?>"><?=$opt['project_name'];?></option>
                                     <? } 
                                     ?>
                                     </select>
                                  </div>

                                  <div class="col-lg-4">
                                    <i class="fa fa-building"></i>
                                    <label>Object name</label>
                                     <input type="text" name="object_name" class="form-control" placeholder="Name of object" required style="background-color: #F8F8F8 !important;">
                                  </div>

                                  <div class="col-lg-4">
                                       <i class="fa fa-bath"></i>
                                       <label>Extra section of object</label><br>
                                       <select name="ob_sec[]" class="js-example-basic-multiple form-control" multiple="multiple" style="background-color: #F8F8F8 !important;width:!important; ">
                                        <?php 
                                          $sql = mysqli_query($link,"SELECT * FROM sections WHERE parent = 'object'");
                                          while($rows = mysqli_fetch_assoc($sql)){
                                             ?>
                                                <option class="form-control" value="<?=$rows['id']?>">
                                                    <?=$rows['section_name']?></option>
                                             <?
                                          }
                                        ?>
                                       </select>
                                    </div>

                                  

                                  

                               </div>

                               <div class="row mb-3" >

                                    <div class="col-lg-4">
                                    <i class="fa fa-arrow-up-1-9"></i>
                                    <label>Floors</label>
                                     <input type="text" name="floors" class="form-control" placeholder="Floor" required style="background-color: #F8F8F8 !important;">
                                  </div>

                                    <div class="col-lg-4">
                                    <i class="fa fa-house"></i>
                                    <label>Flats</label>
                                     <input type="text" name="rooms" class="form-control" placeholder="Room" required style="background-color: #F8F8F8 !important;">
                                  </div>

                                  <div class="col-lg-4">
                                       <label>Comment</label><br>
                                        <div class="row">
                                            <div class="col-md-2">
                                                <input name="check" class=" form-control flexCheckDefault " type="checkbox" value="true" id="flexCheckDefault" style="width:50px !important;height: 35px;background-color:red !important;" onchange="com()" id="">
                                            </div>
                                            <div class="col-md-10 comment" id="com">
                                                <input type="text" name="comment" class="form-control "
                                                style="background-color: #F8F8F8 !important;">
                                            </div>
                                        </div>
                                    </div> 

                                     
                               </div>
                               
                                   <button type="submit" class="btn btn-success float-justify"><h4>Submit</h4></button>
                                 </form>
                                </div>
                            </div>
                         </div>
                      </div>
                  </div>
            

            <div class="card">
                    <div class="card-body">
                       <h3 class="card text-center"><i class="fa fa-hospital-alt"></i> Objects </h3><hr>
                        <div class="table-responsive">
                            <table border="0" cellspacing="5" cellpadding="5">
                                <tbody><tr>
                                    <td>Minimum date:</td>
                                    <td><input type="text" id="min" name="min"></td>
                                </tr>
                                <tr>
                                    <td>Maximum date:</td>
                                    <td><input type="text" id="max" name="max"></td>
                                </tr>
                            </tbody></table>
                            <table id="example" class="display nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Project name</th>
                                        <th>Object name</th>
                                        <th>Floors</th>
                                        <th>Flats</th>
                                        <th>Surface</th>
                                        <th>Fee</th>
                                       <!--  <th>Section</th>
                                        <th>Finished floors</th>
                                        <th>Finished flats</th> -->
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Update</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php 
                                        $sql = mysqli_query($link,"SELECT * FROM objects");
                                        while($row = mysqli_fetch_assoc($sql)){?>
                                            <tr>
                                            <td>
                                                <?php 
                                                    $id = $row['project_id'];
                                                    $sql2 = mysqli_query($link,"SELECT * FROM projects WHERE id = '$id'");
                                                    $res = mysqli_fetch_assoc($sql2);
                                                    echo $res['project_name'];;
                                                ?>
                                            </td>
                                            <td><?=$row['obj_name']?></td>
                                            <td><?=$row['floors']?></td>
                                            <td><?=$row['rooms']?></td>
                                            <td><?=$row['surface']?></td>
                                            <td><?=$row['fee']?></td>
                                            <!-- <td><?=$row['section']?></td>
                                            <td><textarea disabled><?=$row['finished_floor']?></textarea></td>
                                            <td><textarea disabled><?=$row['finished_flat']?></textarea></td> -->
                                            <td>
                                            <?php
                                                if($row['created_date']) echo date("d-m-Y",$row['created_date']);
                                                else echo date("d-m-Y",$row['updated_date']);
                                            ?>
                                          </td>
                                          <td><?=$row['status']?></td>
                                          <td><a href="edit.php?id=<?=$row['id']?>"><i class="fa fa-pencil btn-success p-10"></i></a></td>
                                          <td>
                                            <form id="delete" class="">
                                            <button type="button" class="btn btn-danger uchir" salom="<?=$row['id']?>"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                        <?}
                                      ?>
                                </tbody>
                            </table>
                       </div>
                    </div>
                 </div>

             
           
               
            </div>
            <footer class="footer text-center">
                &copy 2023 All right reserved.
            </footer>
            
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
  <script type="text/javascript" src="../js/jquery-3.6.3.min.js"></script>
  
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
    <!-- This Page JS -->

    <!-- <script src="../js/jquery-3.6.3.min.js"></script> -->
    <script src="../js/sweetalert.min.js"></script>
    <script src="../assets/all.min.js"></script>

    <!-- This Page JS -->
    <!-- <script src="../assets/libs/inputmask/../dist/min/jquery.inputmask.bundle.min.js"></script> -->
    <!-- <script src="../dist/js/pages/mask/mask.init.js"></script> -->
    <script src="../assets/libs/select2/dist/js/select2.full.min.js"></script>
    <script src="../assets/libs/select2/dist/js/select2.min.js"></script>
    <script src="../assets/libs/jquery-asColor/dist/jquery-asColor.min.js"></script>
    <script src="../assets/libs/jquery-asGradient/dist/jquery-asGradient.js"></script>
    <script src="../assets/libs/jquery-asColorPicker/dist/jquery-asColorPicker.min.js"></script>
    <script src="../assets/libs/jquery-minicolors/jquery.minicolors.min.js"></script>
    <script src="../assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="../assets/libs/quill/dist/quill.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript" src="assets/jquery.dataTables.min.js"></script>
 <script type="text/javascript" src="assets/moment.min.js"></script>
 <script type="text/javascript" src="assets/dataTables.dateTime.min.js"></script>
 <!-- <script type="text/javascript" src=".js"></script>  -->
    <script type="text/javascript" src="assets/dataTables.buttons.min.js"></script> 
    <script type="text/javascript" src="assets/jszip.min.js"></script> 
    <script type="text/javascript" src="assets/pdfmake.min.js"></script> 
    <script type="text/javascript" src="assets/vfs_fonts.js"></script> 
    <script type="text/javascript" src="assets/buttons.html5.min.js"></script> 
    <script type="text/javascript" src="assets/buttons.print.min.js"></script>
<script type="text/javascript">
    var minDate, maxDate;
 
// Custom filtering function which will search data in column four between two values
DataTable.ext.search.push(function (settings, data, dataIndex) {
    var min = minDate.val();
    var max = maxDate.val();
    var date = new Date(data[4]);
 
    if (
        (min === null && max === null) ||
        (min === null && date <= max) ||
        (min <= date && max === null) ||
        (min <= date && date <= max)
    ) {
        return true;
    }
    return false;
});
 
// Create date inputs
minDate = new DateTime('#min', {
    format: 'MMMM Do YYYY'
});
maxDate = new DateTime('#max', {
    format: 'MMMM Do YYYY'
});
 
// DataTables initialisation
var table = $('#example').DataTable();
 
// Refilter the table
$('#min, #max').on('change', function () {
    table.draw();
});
 </script>



 <script type="text/javascript">
 
    $(document).ready(function() {
    $('#example').DataTable( {
        destroy:true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
 </script>
    <script type="text/javascript">
        
           $(".js-example-basic-single").css("background-color", "yellow");
           

           $(document).ready(function() {
              $(".js-example-basic-multiple").select2();
              $(".js-example-basic-multiple").css("background-color","gray");
            });

              function myFunction() {
              var x = document.getElementById("card");
              if (x.style.display === "block") {
                  x.style.display = "none";
                  console.log(1111)
              } 
              else {
                  x.style.display = "block";
                  console.log(2222)
              }
        }


      </script>

    <script type="text/javascript">
        $('#object').submit(function(e){
            e.preventDefault();
            let object = $('#object').serialize();

            alert(object)

            $.ajax({
                url: "valid.php",
                type: "POST",
                data: object,
                success:function(data){
                    console.log(data)
                    alert(data)
                    // var obj = jQuery.parseJSON(data);
                    // if(obj.xatolik == 0){
                    //     swal('Good job',obj.xabar,'success');
                    //     function ref() {
                    //         location.reload();
                    //     }

                    //     const p = setTimeout(ref,400);
                    // }
                    // else {
                    //     swal('Error!!!',obj.xabar,'error');
                    // }
                },
                error:function(xhr){
                    alert("Coonnecting error");
                }
            });
        });
    </script>

    <script type="text/javascript">
        $('.uchir').click(function() {
            
            let id = $(this).attr("salom");
            console.log(id);

            swal({
              title: "Are you sure?",
              text: "Once deleted, you will not be able to recover this imaginary file!",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((willDelete) => {
              if (willDelete) {
                swal("Exellent! Project deleted successfully!!!", {
                  icon: "success",
                });
                 function rel(){
                            location.reload();
                }
                const d = setTimeout(rel,300);
                $.ajax({
                url: "delete.php",
                type: "POST",
                data:{
                    id:id,
                },
                success:function(data){
                    console.log(data);
                },
                error:function(xhr){
                    alert("Connecting error!!!")
                }
            }); 

                
              } else {
                swal("Canceled!!!",{
                  icon: "error"});
              }
            });
             });
    </script>

    <script type="text/javascript">
       function  com(){
            var x = document.getElementById("com");
              if (x.style.display === "block") {
                  x.style.display = "none";
                  console.log(1111)
              } 
              else {
                  x.style.display = "block";
                  console.log(2222)
              }
        }
    </script>

  

</body>

</html>
<? }
else {
    header("Location:index.php");
}

?>


<?php 
session_start();
include '../config.php';
include '../date.php';

define("SITE_URL",dirname(dirname($_SERVER['SERVER_NAME'])));

$sql_project = mysqli_query($link,"SELECT * FROM projects");

$title = "OBJECTS - ROBO";

 if($_SESSION['user']){

    require "$_SERVER[DOCUMENT_ROOT]/header.php";   
?>

        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
             <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">
                             <button onclick="myFunction()" class="font-light text-white m-b-20 btn btn-primary" >
                                    <span style="font-size:14px !important;">Add <i class="fa fa-plus"></i></span>
                                   </button  name="add"><br>
                        </h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">

             <div id="" >
                  <div class="row" >
                      <div class="col-lg-12">
                         <div class="card" >
                            <div class="card-body" >
                             <form method="POST" id="object" >
                               <div class="row mb-3" >
                                   <div class="col-lg-4">
                                    <i class=" fas fa-hospital-alt "></i>
                                     <label> Project id</label> 
                                     <select name="project_id" class="form-control" placeholder="Address" required 
                                      style="background-color: #F8F8F8 !important;">
                                     <?php 
                                        foreach($sql_project as $opt){
                                     ?>
                                        <option value="<?=$opt['id'];?>"><?=$opt['project_name'];?></option>
                                     <? } 
                                     ?>
                                     </select>
                                  </div>

                                  <div class="col-lg-4">
                                    <i class="fa fa-building"></i>
                                    <label>Object name</label>
                                     <input type="text" name="object_name" class="form-control" placeholder="Name of object" required style="background-color: #F8F8F8 !important;">
                                  </div>

                                  <div class="col-lg-4">
                                       <i class="fa fa-bath"></i>
                                       <label>Extra section of object</label><br>
                                       <select name="ob_sec[]" class="js-example-basic-multiple form-control" multiple="multiple" style="background-color: #F8F8F8 !important;width:!important; ">
                                        <?php 
                                          $sql = mysqli_query($link,"SELECT * FROM sections WHERE parent = 'object'");
                                          while($rows = mysqli_fetch_assoc($sql)){
                                             ?>
                                                <option class="form-control" value="<?=$rows['id']?>">
                                                    <?=$rows['section_name']?></option>
                                             <?
                                          }
                                        ?>
                                       </select>
                                    </div>

                                  

                                  

                               </div>

                               <div class="row mb-3" >

                                    <div class="col-lg-4">
                                    <i class="fa fa-arrow-up-1-9"></i>
                                    <label>Floors</label>
                                     <input type="text" name="floors" class="form-control" placeholder="Floor" required style="background-color: #F8F8F8 !important;">
                                  </div>

                                    <div class="col-lg-4">
                                    <i class="fa fa-house"></i>
                                    <label>Flats</label>
                                     <input type="text" name="rooms" class="form-control" placeholder="Room" required style="background-color: #F8F8F8 !important;">
                                  </div>

                                  <div class="col-lg-4">
                                       <label>Finish</label><br>
                                        <div class="row">
                                            <div class="col-md-2">
                                                <input name="check" class=" form-control flexCheckDefault " type="checkbox" value="true" id="flexCheckDefault" style="width:50px !important;height: 35px;background-color:red !important;" onchange="com()" id="">
                                            </div>
                                            <div class="col-md-10 comment" id="com">
                                                <input type="text" name="comment" class="form-control "
                                                style="background-color: #F8F8F8 !important;">
                                            </div>
                                        </div>
                                    </div> 

                                     
                               </div>
                               
                                   <button type="submit" class="btn btn-success float-justify"><h4>Submit</h4></button>
                                 </form>
                                </div>
                            </div>
                         </div>
                      </div>
                  </div>
            

            <div class="card">
                    <div class="card-body">
                       <h3 class="card text-center"><i class="fa fa-hospital-alt"></i> Objects </h3><hr>
                        <div class="table-responsive">
                            <table border="0" cellspacing="5" cellpadding="5">
                                <tbody><tr>
                                    <td>Minimum date:</td>
                                    <td><input type="text" id="min" name="min"></td>
                                </tr>
                                <tr>
                                    <td>Maximum date:</td>
                                    <td><input type="text" id="max" name="max"></td>
                                </tr>
                            </tbody></table>
                            <table id="example" class="display nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Project name</th>
                                        <th>Object name</th>
                                        <th>Floors</th>
                                        <th>Flats</th>
                                        <th>Surface</th>
                                        <th>Fee</th>
                                       <!--  <th>Section</th>
                                        <th>Finished floors</th>
                                        <th>Finished flats</th> -->
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Update</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php 
                                        $sql = mysqli_query($link,"SELECT * FROM objects");
                                        while($row = mysqli_fetch_assoc($sql)){?>
                                            <tr>
                                            <td>
                                                <?php 
                                                    $id = $row['project_id'];
                                                    $sql2 = mysqli_query($link,"SELECT * FROM projects WHERE id = '$id'");
                                                    $res = mysqli_fetch_assoc($sql2);
                                                    echo $res['project_name'];;
                                                ?>
                                            </td>
                                            <td><?=$row['obj_name']?></td>
                                            <td><?=$row['floors']?></td>
                                            <td><?=$row['rooms']?></td>
                                            <td><?=$row['surface']?></td>
                                            <td><?=$row['fee']?></td>
                                            <!-- <td><?=$row['section']?></td>
                                            <td><textarea disabled><?=$row['finished_floor']?></textarea></td>
                                            <td><textarea disabled><?=$row['finished_flat']?></textarea></td> -->
                                            <td>
                                            <?php
                                                if($row['created_date']) echo date("d-m-Y",$row['created_date']);
                                                else echo date("d-m-Y",$row['updated_date']);
                                            ?>
                                          </td>
                                          <td><?=$row['status']?></td>
                                          <td><a href="edit.php?id=<?=$row['id']?>"><i class="fa fa-pencil btn-success p-10"></i></a></td>
                                          <td>
                                            <form id="delete" class="">
                                            <button type="button" class="btn btn-danger uchir" salom="<?=$row['id']?>"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                        <?}
                                      ?>
                                </tbody>
                            </table>
                       </div>
                    </div>
                 </div>

             
           
               
            </div>
            <footer class="footer text-center">
                &copy 2023 All right reserved.
            </footer>
            
        </div>
        <!-- End Page wrapper  -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
  <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
    <!-- This Page JS -->

    <!-- <script src="../js/jquery-3.6.3.min.js"></script> -->
    <script src="../js/sweetalert.min.js"></script>
    <script src="../assets/all.min.js"></script>

    <!-- This Page JS -->
    <!-- <script src="../assets/libs/inputmask/../dist/min/jquery.inputmask.bundle.min.js"></script> -->
    <!-- <script src="../dist/js/pages/mask/mask.init.js"></script> -->
    <script src="../assets/libs/select2/dist/js/select2.full.min.js"></script>
    <script src="../assets/libs/select2/dist/js/select2.min.js"></script>
    <script src="../assets/libs/jquery-asColor/dist/jquery-asColor.min.js"></script>
    <script src="../assets/libs/jquery-asGradient/dist/jquery-asGradient.js"></script>
    <script src="../assets/libs/jquery-asColorPicker/dist/jquery-asColorPicker.min.js"></script>
    <script src="../assets/libs/jquery-minicolors/jquery.minicolors.min.js"></script>
    <script src="../assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="../assets/libs/quill/dist/quill.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript" src="assets/jquery.dataTables.min.js"></script>
 <script type="text/javascript" src="assets/moment.min.js"></script>
 <script type="text/javascript" src="assets/dataTables.dateTime.min.js"></script>
 <!-- <script type="text/javascript" src=".js"></script>  -->
    <script type="text/javascript" src="assets/dataTables.buttons.min.js"></script> 
    <script type="text/javascript" src="assets/jszip.min.js"></script> 
    <script type="text/javascript" src="assets/pdfmake.min.js"></script> 
    <script type="text/javascript" src="assets/vfs_fonts.js"></script> 
    <script type="text/javascript" src="assets/buttons.html5.min.js"></script> 
    <script type="text/javascript" src="assets/buttons.print.min.js"></script>
<script type="text/javascript">
    var minDate, maxDate;
 
// Custom filtering function which will search data in column four between two values
DataTable.ext.search.push(function (settings, data, dataIndex) {
    var min = minDate.val();
    var max = maxDate.val();
    var date = new Date(data[4]);
 
    if (
        (min === null && max === null) ||
        (min === null && date <= max) ||
        (min <= date && max === null) ||
        (min <= date && date <= max)
    ) {
        return true;
    }
    return false;
});
 
// Create date inputs
minDate = new DateTime('#min', {
    format: 'MMMM Do YYYY'
});
maxDate = new DateTime('#max', {
    format: 'MMMM Do YYYY'
});
 
// DataTables initialisation
var table = $('#example').DataTable();
 
// Refilter the table
$('#min, #max').on('change', function () {
    table.draw();
});
 </script>



 <script type="text/javascript">
 
    $(document).ready(function() {
    $('#example').DataTable( {
        destroy:true,
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
 </script>
    <script type="text/javascript">
        
           $(".js-example-basic-single").css("background-color", "yellow");
           

           $(document).ready(function() {
              $(".js-example-basic-multiple").select2();
              $(".js-example-basic-multiple").css("background-color","gray");
            });

              function myFunction() {
              var x = document.getElementById("card");
              if (x.style.display === "block") {
                  x.style.display = "none";
                  console.log(1111)
              } 
              else {
                  x.style.display = "block";
                  console.log(2222)
              }
        }


      </script>

    <script type="text/javascript">
        $('#object').submit(function(e){
            e.preventDefault();
            let object = $('#object').serialize();

            $.ajax({
                url: "valid.php",
                type: "POST",
                data: object,
                success:function(data){
                    console.log(data)
                    alert(data)
                    // var obj = jQuery.parseJSON(data);
                    // if(obj.xatolik == 0){
                    //     swal('Good job',obj.xabar,'success');
                    //     function ref() {
                    //         location.reload();
                    //     }

                    //     const p = setTimeout(ref,400);
                    // }
                    // else {
                    //     swal('Error!!!',obj.xabar,'error');
                    // }
                },
                error:function(xhr){
                    alert("Coonnecting error");
                }
            });
        });
    </script>

    <script type="text/javascript">
        $('.uchir').click(function() {
            
            let id = $(this).attr("salom");
            console.log(id);

            swal({
              title: "Are you sure?",
              text: "Once deleted, you will not be able to recover this imaginary file!",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            })
            .then((willDelete) => {
              if (willDelete) {
                swal("Exellent! Project deleted successfully!!!", {
                  icon: "success",
                });
                 function rel(){
                            location.reload();
                }
                const d = setTimeout(rel,300);
                $.ajax({
                url: "delete.php",
                type: "POST",
                data:{
                    id:id,
                },
                success:function(data){
                    console.log(data);
                },
                error:function(xhr){
                    alert("Connecting error!!!")
                }
            }); 

                
              } else {
                swal("Canceled!!!",{
                  icon: "error"});
              }
            });
             });
    </script>

    <script type="text/javascript">
       function  com(){
            var x = document.getElementById("com");
              if (x.style.display === "block") {
                  x.style.display = "none";
                  console.log(1111)
              } 
              else {
                  x.style.display = "block";
                  console.log(2222)
              }
        }
    </script>

  

</body>

</html>
<? }
else {
    header("Location:index.php");
}

?>

























<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
   <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/datetime/1.4.1/css/dataTables.dateTime.min.css">
</head>
<body>


<table border="0" cellspacing="5" cellpadding="5">
   <tbody>
      <tr>
         <td>Minimum date:</td>
         <td><input type="text" id="min" name="min" autocomplete="off"></td>
      </tr>
      <tr>
         <td>Maximum date:</td>
         <td><input type="text" id="max" name="max" autocomplete="off"></td>
      </tr>
   </tbody>
</table>
<div id="example_wrapper" class="dataTables_wrapper">
   <div class="dataTables_length" id="example_length">
      <label>
         Show 
         <select name="example_length" aria-controls="example" class="">
            <option value="10">10</option>
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
         </select>
         entries
      </label>
   </div>
   <div id="example_filter" class="dataTables_filter"><label>Search:<input type="search" class="" placeholder="" aria-controls="example"></label></div>
   <table id="example" class="display nowrap dataTable" style="width:100%" aria-describedby="example_info">
      <thead>
         <tr>
            <th class="sorting sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 133.4px;">Name</th>
            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 221.575px;">Position</th>
            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 98.75px;">Office</th>
            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 40.0125px;">Age</th>
            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Start date: activate to sort column ascending" style="width: 87.175px;">Start date</th>
            <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 74.7625px;">Salary</th>
         </tr>
      </thead>
      <tbody>
         <tr class="odd">
            <td class="sorting_1">Airi Satou</td>
            <td>Accountant</td>
            <td>Tokyo</td>
            <td>33</td>
            <td>2008-11-28</td>
            <td>$162,700</td>
         </tr>
         <tr class="even">
            <td class="sorting_1">Angelica Ramos</td>
            <td>Chief Executive Officer (CEO)</td>
            <td>London</td>
            <td>47</td>
            <td>2009-10-09</td>
            <td>$1,200,000</td>
         </tr>
         <tr class="odd">
            <td class="sorting_1">Ashton Cox</td>
            <td>Junior Technical Author</td>
            <td>San Francisco</td>
            <td>66</td>
            <td>2009-01-12</td>
            <td>$86,000</td>
         </tr>
         <tr class="even">
            <td class="sorting_1">Bradley Greer</td>
            <td>Software Engineer</td>
            <td>London</td>
            <td>41</td>
            <td>2012-10-13</td>
            <td>$132,000</td>
         </tr>
         <tr class="odd">
            <td class="sorting_1">Brenden Wagner</td>
            <td>Software Engineer</td>
            <td>San Francisco</td>
            <td>28</td>
            <td>2011-06-07</td>
            <td>$206,850</td>
         </tr>
         <tr class="even">
            <td class="sorting_1">Brielle Williamson</td>
            <td>Integration Specialist</td>
            <td>New York</td>
            <td>61</td>
            <td>2012-12-02</td>
            <td>$372,000</td>
         </tr>
         <tr class="odd">
            <td class="sorting_1">Bruno Nash</td>
            <td>Software Engineer</td>
            <td>London</td>
            <td>38</td>
            <td>2011-05-03</td>
            <td>$163,500</td>
         </tr>
         <tr class="even">
            <td class="sorting_1">Caesar Vance</td>
            <td>Pre-Sales Support</td>
            <td>New York</td>
            <td>21</td>
            <td>2011-12-12</td>
            <td>$106,450</td>
         </tr>
         <tr class="odd">
            <td class="sorting_1">Cara Stevens</td>
            <td>Sales Assistant</td>
            <td>New York</td>
            <td>46</td>
            <td>2011-12-06</td>
            <td>$145,600</td>
         </tr>
         <tr class="even">
            <td class="sorting_1">Cedric Kelly</td>
            <td>Senior Javascript Developer</td>
            <td>Edinburgh</td>
            <td>22</td>
            <td>2012-03-29</td>
            <td>$433,060</td>
         </tr>
      </tbody>
      <tfoot>
         <tr>
            <th rowspan="1" colspan="1">Name</th>
            <th rowspan="1" colspan="1">Position</th>
            <th rowspan="1" colspan="1">Office</th>
            <th rowspan="1" colspan="1">Age</th>
            <th rowspan="1" colspan="1">Start date</th>
            <th rowspan="1" colspan="1">Salary</th>
         </tr>
      </tfoot>
   </table>
   <div class="dataTables_info" id="example_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
   <div class="dataTables_paginate paging_simple_numbers" id="example_paginate"><a class="paginate_button previous disabled" aria-controls="example" aria-disabled="true" aria-role="link" data-dt-idx="previous" tabindex="-1" id="example_previous">Previous</a><span><a class="paginate_button current" aria-controls="example" aria-role="link" aria-current="page" data-dt-idx="0" tabindex="0">1</a><a class="paginate_button " aria-controls="example" aria-role="link" data-dt-idx="1" tabindex="0">2</a><a class="paginate_button " aria-controls="example" aria-role="link" data-dt-idx="2" tabindex="0">3</a><a class="paginate_button " aria-controls="example" aria-role="link" data-dt-idx="3" tabindex="0">4</a><a class="paginate_button " aria-controls="example" aria-role="link" data-dt-idx="4" tabindex="0">5</a><a class="paginate_button " aria-controls="example" aria-role="link" data-dt-idx="5" tabindex="0">6</a></span><a class="paginate_button next" aria-controls="example" aria-role="link" data-dt-idx="next" tabindex="0" id="example_next">Next</a></div>
</div>
<script type="text/javascript" src="js/jquery-3.6.3.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.2/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/datetime/1.4.1/js/dataTables.dateTime.min.js"></script>
<script type="text/javascript">
   var minDate, maxDate;
// Custom filtering function which will search data in column four between two values
DataTable.ext.search.push(function (settings, data, dataIndex) {
var min = minDate.val();
var max = maxDate.val();
var date = new Date(data[4]);
if (
(min === null && max === null) ||
(min === null && date <= max) ||
(min <= date && max === null) ||
(min <= date && date <= max)
) {
return true;
}
return false;
});
// Create date inputs
minDate = new DateTime('#min', {
format: 'MMMM Do YYYY'
});
maxDate = new DateTime('#max', {
format: 'MMMM Do YYYY'
});
// DataTables initialisation
var table = $('#example').DataTable();
// Refilter the table
$('#min, #max').on('change', function () {
table.draw();
});
</script>
</body>
</html>